# Binance Futures Testnet Trading Bot

A Python CLI application to place Market, Limit, and Stop-Market orders on the **Binance Futures Testnet (USDT-M)**. Built with a clean, layered architecture, structured logging, and full error handling.

---

## Project Structure

```
trading_bot/
├── bot/
│   ├── __init__.py
│   ├── client.py          # Binance API client (HTTP + signing)
│   ├── orders.py          # Order placement logic + output formatting
│   ├── validators.py      # Input validation
│   └── logging_config.py  # Logger setup (file + console)
├── cli.py                 # CLI entry point (argparse)
├── logs/                  # Auto-created; log files written here
├── requirements.txt
└── README.md
```

---

## Setup

### 1. Register on Binance Futures Testnet

1. Go to [https://testnet.binancefuture.com](https://testnet.binancefuture.com)
2. Sign in with GitHub
3. Navigate to **API Key** section and generate credentials
4. Copy your **API Key** and **Secret Key**

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

---

## How to Run

### Option A — Pass credentials as arguments

```bash
python cli.py \
  --api-key YOUR_API_KEY \
  --api-secret YOUR_API_SECRET \
  --symbol BTCUSDT \
  --side BUY \
  --type MARKET \
  --quantity 0.001
```

### Option B — Use environment variables (recommended)

```bash
export BINANCE_API_KEY=your_key
export BINANCE_API_SECRET=your_secret
```

Then run without credential flags:

```bash
python cli.py --symbol BTCUSDT --side BUY --type MARKET --quantity 0.001
```

---

## Usage Examples

### Place a MARKET BUY order
```bash
python cli.py --symbol BTCUSDT --side BUY --type MARKET --quantity 0.001
```

### Place a LIMIT SELL order
```bash
python cli.py --symbol BTCUSDT --side SELL --type LIMIT --quantity 0.001 --price 65000
```

### Place a STOP_MARKET order (bonus order type)
```bash
python cli.py --symbol BTCUSDT --side SELL --type STOP_MARKET --quantity 0.001 --price 60000
```

### View help
```bash
python cli.py --help
```

---

## Sample Output

```
✅ Connected to Binance Futures Testnet

==================================================
        ORDER REQUEST SUMMARY
==================================================
  Symbol     : BTCUSDT
  Side       : BUY
  Type       : MARKET
  Quantity   : 0.001
==================================================

--------------------------------------------------
        ORDER RESPONSE
--------------------------------------------------
  Order ID   : 3279890123
  Symbol     : BTCUSDT
  Status     : FILLED
  Side       : BUY
  Type       : MARKET
  Quantity   : 0.001
  Exec. Qty  : 0.001
  Avg Price  : 67432.10
--------------------------------------------------

✅ Order placed successfully! Order ID: 3279890123
```

---

## Logging

Logs are written to `logs/trading_bot_YYYYMMDD.log`. Each entry includes:
- Timestamp
- Log level
- API request parameters
- Full API response
- Errors and exceptions with tracebacks

---

## Assumptions

- All orders are placed on **Binance Futures Testnet** (`https://testnet.binancefuture.com`), never on live Binance.
- Quantity precision must match the symbol's filter rules on testnet (e.g. `0.001` BTC minimum for BTCUSDT).
- LIMIT orders use `timeInForce=GTC` (Good Till Cancelled) by default.
- STOP_MARKET is the bonus third order type implemented.
- No position management or order cancellation is in scope for this task.

---

## Requirements

- Python 3.8+
- `requests` library (see `requirements.txt`)
